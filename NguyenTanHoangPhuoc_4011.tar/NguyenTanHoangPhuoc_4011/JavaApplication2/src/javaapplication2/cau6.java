/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;
import java.util.Arrays;
/**
 *
 * @author Admin
 */
public class cau6 {
    int[] array = {1, 2, 3, 4, 5};  
        int sum = 0;  

        for (int i = 0; i < array.length; i++) {
            sum += array[i];
        }

        System.out.println("Sum of all elements: " + sum);
    }

